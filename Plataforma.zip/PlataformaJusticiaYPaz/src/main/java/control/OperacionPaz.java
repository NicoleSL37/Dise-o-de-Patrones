package control;

public interface OperacionPaz {

    void procesar();

}
