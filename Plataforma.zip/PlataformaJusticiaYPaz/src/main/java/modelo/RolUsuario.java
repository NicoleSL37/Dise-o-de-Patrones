package modelo;

public enum RolUsuario {
    ADMINISTRADOR, INVESTIGADOR, USUARIO
}
